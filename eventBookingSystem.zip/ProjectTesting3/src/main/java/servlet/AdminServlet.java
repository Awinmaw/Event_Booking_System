package servlet;
import dao.EventDAO;
import model.Event;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class AdminServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if("add".equals(action) || "edit".equals(action)){
            try{
                Event e = new Event();
                if("edit".equals(action)) e.setId(Integer.parseInt(request.getParameter("id")));
                e.setName(request.getParameter("name"));
                e.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date")));
                e.setLocation(request.getParameter("location"));
                e.setPrice(Double.parseDouble(request.getParameter("price")));
                if("add".equals(action)){
                    EventDAO.addEvent(e);
                } else {
                    EventDAO.updateEvent(e);
                }
            } catch(Exception ex){ ex.printStackTrace(); }
        }
        response.sendRedirect("admin/dashboard.jsp");
    }

    /*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if("delete".equals(action)){
            int id = Integer.parseInt(request.getParameter("id"));
            EventDAO.deleteEvent(id);
        }
        response.sendRedirect("admin/dashboard.jsp");
    }*/
    
    // fixed
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            try {
                String idParam = request.getParameter("id");
                if (idParam == null) {
                    request.getSession().setAttribute("msg", "❌ Event ID missing");
                    response.sendRedirect("admin/dashboard.jsp");
                    return;
                }

                int id = Integer.parseInt(idParam);
                boolean deleted = EventDAO.deleteEvent(id);

                if (deleted) {
                    request.getSession().setAttribute("msg", "✅ Event deleted successfully!");
                } else {
                    request.getSession().setAttribute("msg", "⚠️ Event not found!");
                }

            } catch (NumberFormatException e) {
                e.printStackTrace();
                request.getSession().setAttribute("msg", "❌ Invalid Event ID");
            } catch (Exception e) {
                e.printStackTrace();
                request.getSession().setAttribute("msg", "❌ Error deleting event");
            }
        }

        // Always redirect back to dashboard
        response.sendRedirect("admin/dashboard.jsp");
    }


}