/*package servlet;
import dao.UserDAO;
import model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = new User();
        
        user.setUsername(request.getParameter("username"));
        user.setEmail(request.getParameter("email"));
        user.setPassword(request.getParameter("password"));
        user.setRole(request.getParameter("role"));
        
        if(UserDAO.register(user)){
            response.sendRedirect("login.jsp?success=registered");
        } else {
            response.sendRedirect("register.jsp?error=fail");
        }
    }
}*/


package servlet;

import dao.UserDAO;
import model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = new User();
        
        user.setUsername(request.getParameter("username"));
        user.setEmail(request.getParameter("email"));
        user.setPassword(request.getParameter("password"));
        user.setRole(request.getParameter("role"));
        
        boolean success = UserDAO.register(user);
        
        if(success) {
            // Check if role is admin
            if("admin".equalsIgnoreCase(user.getRole())) {
                // Admin added another admin → go to dashboard
                response.sendRedirect("admin/dashboard.jsp?success=adminAdded");
            } else {
                // Normal user registered → go to login page
                response.sendRedirect("login.jsp?success=registered");
            }
        } else {
            // Failed registration
            if("admin".equalsIgnoreCase(user.getRole())) {
                response.sendRedirect("admin/addAdmin.jsp?error=fail");
            } else {
                response.sendRedirect("register.jsp?error=fail");
            }
        }
    }
}
