package servlet;
import dao.EventDAO;
import model.Event;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class EventServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Event> events = EventDAO.getAllEvents();
        request.setAttribute("events", events);
        request.getRequestDispatcher("events.jsp").forward(request,response);
    }
}