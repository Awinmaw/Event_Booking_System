package servlet;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AddAdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);
        model.User currentUser = (session != null) ? (model.User) session.getAttribute("user") : null;

        // only admins can add admins
        if (currentUser == null || !"admin".equalsIgnoreCase(currentUser.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        String username = req.getParameter("username");
        String password = req.getParameter("password");

        boolean success = UserDAO.addAdmin(username, password);

        if (success) {
            req.getSession().setAttribute("msg", "✅ New admin added successfully!");
        } else {
            req.getSession().setAttribute("msg", "❌ Failed to add new admin!");
        }

        resp.sendRedirect(req.getContextPath() + "/admin/dashboard.jsp");
    }
}
