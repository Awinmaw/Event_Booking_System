package servlet;

import dao.UserDAO;
import model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.List;

@WebServlet("/AdminUserServlet")
public class ManipulateUserServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Check if delete action
        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                boolean deleted = UserDAO.deleteUser(id);
                if (deleted) {
                    request.getSession().setAttribute("msg", "✅ User deleted successfully!");
                } else {
                    request.getSession().setAttribute("msg", "⚠️ Couldn't delete this user!");
                }
            } catch (Exception e) {
                e.printStackTrace();
                request.getSession().setAttribute("msg", "❌ Error deleting user!");
            }
            response.sendRedirect("AdminUserServlet");
            return;
        }

        // Normal view
        List<User> users = UserDAO.getAllUsers();
        request.setAttribute("users", users);
        RequestDispatcher rd = request.getRequestDispatcher("admin/viewUser.jsp");
        rd.forward(request, response);
    }
}
