package servlet;

import dao.BookingDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;
import model.Booking;
import model.User;

public class AdminBookingServlet extends HttpServlet {
    private BookingDAO bookingDAO = new BookingDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null || !"admin".equalsIgnoreCase(user.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        // Fetch all bookings
        List<Booking> bookings = bookingDAO.getAllBookings();
        req.setAttribute("bookings", bookings);
        req.getRequestDispatcher("/admin/bookings.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null || !"admin".equalsIgnoreCase(user.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        // Handle deleting a booking
        String action = req.getParameter("action");
        if ("delete".equals(action)) {
            int bookingId = Integer.parseInt(req.getParameter("bookingId"));
            BookingDAO dao = new BookingDAO();
            bookingDAO.deleteBooking(bookingId);
        }

        resp.sendRedirect(req.getContextPath() + "/AdminBookingServlet");
    }
}
