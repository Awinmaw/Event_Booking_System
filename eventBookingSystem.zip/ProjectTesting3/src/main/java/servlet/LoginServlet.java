/*package servlet;

import java.io.IOException;
import dao.UserDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import model.User;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get email and password from the login form
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Authenticate user
        User user = UserDAO.login(email, password);

        if (user != null) {
            // Create session and store user object
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // Redirect based on role
            if ("admin".equalsIgnoreCase(user.getRole())) {
                response.sendRedirect("admin/dashboard.jsp");
            } else {
                response.sendRedirect("events.jsp");
            }
        } else {
            // Invalid credentials
            response.sendRedirect("login.jsp?error=invalid");
        }
    }
}*/

package servlet;
import java.io.IOException;
import dao.UserDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import model.User;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	/*HttpSession session1 = request.getSession();
    	session1.setAttribute("loginError", "❌ Invalid username or password");
    	response.sendRedirect("login.jsp");*/


        // Get login credentials
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Check for empty fields
        if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
            response.sendRedirect("login.jsp?error=empty");
            return;
        }

        // Authenticate user
        User user = UserDAO.login(email, password);

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user); // store only the user object

            if ("admin".equalsIgnoreCase(user.getRole())) {
                response.sendRedirect("admin/dashboard.jsp");
            } else {
                response.sendRedirect("events.jsp");
            }
        } else {
            response.sendRedirect("login.jsp?error=invalid");
        }



    }
}

