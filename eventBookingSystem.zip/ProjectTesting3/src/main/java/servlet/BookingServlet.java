package servlet;

import dao.BookingDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class BookingServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        model.User user = (session != null) ? (model.User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect("login.jsp?error=notLoggedIn");
            return;
        }

        int eventId;
        try {
            eventId = Integer.parseInt(request.getParameter("eventId"));
        } catch (NumberFormatException e) {
            response.sendRedirect("events.jsp?error=invalidId");
            return;
        }

        int userId = user.getId();

        if (BookingDAO.bookEvent(userId, eventId)) {
            // Forward to secure JSP under WEB-INF
            request.getRequestDispatcher("/WEB-INF/mybookings.jsp").forward(request, response);
        } else {
            response.sendRedirect("events.jsp?error=fail");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        model.User user = (session != null) ? (model.User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect("login.jsp?error=notLoggedIn");
            return;
        }

        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            try {
                int bookingId = Integer.parseInt(request.getParameter("bookingId"));
                BookingDAO.deleteBooking(bookingId); // You must implement this in BookingDAO
            } catch (NumberFormatException e) {
                // ignore or log invalid id
            }
        }

        // Refresh booking list
        doGet(request, response);
    }

}
