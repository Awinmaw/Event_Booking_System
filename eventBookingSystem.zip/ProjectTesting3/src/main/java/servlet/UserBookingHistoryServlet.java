package servlet;

import dao.BookingDAO;
import model.Booking;
import model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class UserBookingHistoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get logged-in user from session
        User currentUser = (User) request.getSession().getAttribute("user");

        if (currentUser == null) {
            // Not logged in → redirect to login page
            response.sendRedirect("login.jsp?error=Please login first");
            return;
        }

        // Fetch bookings for this user
        List<Booking> bookings = BookingDAO.getUserBookings(currentUser.getId());

        // Attach list to request
        request.setAttribute("bookings", bookings);

        // Forward to JSP
        RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/mybookings.jsp");
        rd.forward(request, response);
    }
}
