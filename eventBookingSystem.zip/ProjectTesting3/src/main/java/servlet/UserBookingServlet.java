package servlet;

import dao.BookingDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import model.User;

public class UserBookingServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        String action = req.getParameter("action");
        if ("delete".equals(action)) {
            int bookingId = Integer.parseInt(req.getParameter("bookingId"));
            BookingDAO.deleteBooking(bookingId, user.getId()); // delete only user’s booking
            req.setAttribute("msg", "Booking deleted successfully!");
        }

        // Forward to JSP under WEB-INF
        req.getRequestDispatcher("/WEB-INF/mybookings.jsp").forward(req, resp);
    }
}
