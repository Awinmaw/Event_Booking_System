package dao;
import model.Event;
import java.sql.*;
import java.util.*;

public class EventDAO {
    public static List<Event> getAllEvents() {
        List<Event> list = new ArrayList<>();
        try(Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM events")) {
            while(rs.next()){
                Event e = new Event();
                e.setId(rs.getInt("id"));
                e.setName(rs.getString("name"));
                e.setDate(rs.getDate("date"));
                e.setLocation(rs.getString("location"));
                e.setPrice(rs.getDouble("price"));
                list.add(e);
            }
        } catch(Exception e) { e.printStackTrace(); }
        return list;
    }

    public static boolean addEvent(Event e) {
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO events(name,date,location,price) VALUES(?,?,?,?)")) {
            ps.setString(1,e.getName());
            ps.setDate(2,new java.sql.Date(e.getDate().getTime()));
            ps.setString(3,e.getLocation());
            ps.setDouble(4,e.getPrice());
            return ps.executeUpdate() > 0;
        } catch(Exception ex){ ex.printStackTrace(); }
        return false;
    }
//Add these methods in EventDAO.java

public static boolean updateEvent(Event e){
 try(Connection conn = DBConnection.getConnection();
     PreparedStatement ps = conn.prepareStatement("UPDATE events SET name=?, date=?, location=?, price=? WHERE id=?")){
     ps.setString(1, e.getName());
     ps.setDate(2, new java.sql.Date(e.getDate().getTime()));
     ps.setString(3, e.getLocation());
     ps.setDouble(4, e.getPrice());
     ps.setInt(5, e.getId());
     return ps.executeUpdate() > 0;
 } catch(Exception ex){ ex.printStackTrace(); }
 return false;
}

/*public static boolean deleteEvent(int id){
 try(Connection conn = DBConnection.getConnection();
     PreparedStatement ps = conn.prepareStatement("DELETE FROM events WHERE id=?")){
     ps.setInt(1,id);
     return ps.executeUpdate() > 0;
 } catch(Exception ex){ ex.printStackTrace(); }
 return false;
}*/

public static boolean deleteEvent(int id){
    try(Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("DELETE FROM events WHERE id=?")){
        ps.setInt(1,id);
        int rows = ps.executeUpdate();
        System.out.println("Delete attempted for ID " + id + ", rows affected = " + rows);
        return rows > 0;
    } catch(Exception ex){ ex.printStackTrace(); }
    return false;
}
}