package dao;
import java.sql.*;

public class DBConnection {
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch(Exception e) { e.printStackTrace(); }
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/eventdb", "root", "");
    }
}