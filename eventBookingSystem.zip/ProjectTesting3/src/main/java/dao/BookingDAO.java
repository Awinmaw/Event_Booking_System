package dao;
import model.Booking;
import java.sql.*;
import java.util.*;

public class BookingDAO {
    public static boolean bookEvent(int userId, int eventId) {
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO bookings(user_id,event_id) VALUES(?,?)")) {
            ps.setInt(1,userId);
            ps.setInt(2,eventId);
            return ps.executeUpdate() > 0;
        } catch(Exception e){ e.printStackTrace(); }
        return false;
    }

    public static List<Booking> getUserBookings(int userId) {
        List<Booking> list = new ArrayList<>();
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM bookings WHERE user_id=?")) {
            ps.setInt(1,userId);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Booking b = new Booking();
                b.setId(rs.getInt("id"));
                b.setUserId(rs.getInt("user_id"));
                b.setEventId(rs.getInt("event_id"));
                b.setBookingDate(rs.getTimestamp("booking_date"));
                list.add(b);
            }
        } catch(Exception e){ e.printStackTrace(); }
        return list;
    }
    
    public List<Booking> getAllBookings() {
        List<Booking> list = new ArrayList<>();
        String sql = "SELECT * FROM bookings";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Booking booking = new Booking();
                booking.setId(rs.getInt("id"));
                booking.setUserId(rs.getInt("user_id"));
                booking.setEventId(rs.getInt("event_id"));
                booking.setBookingDate(rs.getTimestamp("booking_date"));
                list.add(booking);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static boolean deleteBooking(int bookingId) {
        boolean success = false;
        String sql = "DELETE FROM bookings WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookingId);
            int rows = ps.executeUpdate();
            success = rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return success;
    }
    
    public static boolean deleteBooking(int bookingId, int userId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM bookings WHERE id=? AND user_id=?")) {
            ps.setInt(1, bookingId);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


}